package com.machina.api.client.cinema.effect;

public interface CameraEffect {
	public void tickEffect(int tick);
}