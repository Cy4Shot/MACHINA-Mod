package com.machina.api.util.loader;

public interface JsonInfo<T> {

	public T cast();

}
