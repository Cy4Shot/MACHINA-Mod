package com.machina.registration.init;

public class MultiblockInit {
	
//	public static final ResourceLocation TEST = new MachinaRL("test");

}